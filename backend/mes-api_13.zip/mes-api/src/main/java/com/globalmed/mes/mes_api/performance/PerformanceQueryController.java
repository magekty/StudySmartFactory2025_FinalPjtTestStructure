// performance/PerformanceQueryController.java
package com.globalmed.mes.mes_api.performance;

import com.globalmed.mes.mes_api.common.PageResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/performances")
@RequiredArgsConstructor
public class PerformanceQueryController {
    private final PerformanceRepo repo;

    @GetMapping
    public PageResponse<ProductionPerformanceEntity> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "startTime,desc") String sort) {

        var sp = sort.split(",");
        var pageable = PageRequest.of(page, size,
                (sp.length==2 && "asc".equalsIgnoreCase(sp[1])) ? Sort.by(sp[0]).ascending()
                        : Sort.by(sp[0]).descending());
        var result = repo.findAll(pageable);
        return PageResponse.of(result, sort);
    }
}