export default function EquipStatusPage(){
  return (
    <div>
      <h1 className="text-lg font-semibold mb-3">설비 상태</h1>
      <p className="text-sm text-gray-600">여기서 RUN 등록/목록을 붙일 예정</p>
    </div>
  );
}