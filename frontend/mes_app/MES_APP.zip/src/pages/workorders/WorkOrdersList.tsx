import { useQuery } from "@tanstack/react-query";
import { api } from "../../lib/api";
import { toPage } from "../../adapters/page";
import type { PageResponse } from "../../types/api";

type WorkOrderItem = {
  workOrderId: string; workOrderNumber: string;
  itemId: string; processId: string; equipmentId: string;
  orderQty: number; producedQty: number; status: string | null;
};

export default function WorkOrdersList() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["work-orders", 0, 20, "createdAt,desc"],
    queryFn: async () => {
      const res = await api.get<PageResponse<WorkOrderItem>>(
        "/work-orders", { params: { page: 0, size: 20, sort: "createdAt,desc" } }
      );
      return toPage(res.data);
    }
  });

  if (isLoading) return <div>로딩...</div>;
  if (error)     return <div>오류</div>;

  return (
    <div>
      <h1 className="text-lg font-semibold mb-3">작업지시</h1>
      <table className="w-full border">
        <thead><tr className="bg-gray-100">
          <th className="p-2 text-left">번호</th>
          <th className="p-2 text-left">품목</th>
          <th className="p-2 text-left">설비</th>
          <th className="p-2 text-right">지시</th>
          <th className="p-2 text-right">누적</th>
          <th className="p-2 text-left">상태</th>
        </tr></thead>
        <tbody>
        {data!.items.map((it) => (
          <tr key={it.workOrderId} className="border-t">
            <td className="p-2">{it.workOrderNumber}</td>
            <td className="p-2">{it.itemId}</td>
            <td className="p-2">{it.equipmentId}</td>
            <td className="p-2 text-right">{it.orderQty}</td>
            <td className="p-2 text-right">{it.producedQty}</td>
            <td className="p-2">{it.status ?? "-"}</td>
          </tr>
        ))}
        </tbody>
      </table>
    </div>
  );
}